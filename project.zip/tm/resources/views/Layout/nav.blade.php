<header class="navbar navbar-dark strick-top bg-dark flex-md-nowrap p-0 shasow">
    <a href="#" class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6">
        Task manager
    </a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse"
    data-bs-targe="#sidebarmenu">
       <span class="navbar-toggler-icon"></span> 
    </button>
   <div class="navbar-nav">
        <div class="nav-item text-nowrap">
           <a class="#">All task</a>
        </div>
  </div>
</header>