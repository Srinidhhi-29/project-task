<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAsk  manager  <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('Layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
   <?php echo $__env->yieldContent('content'); ?>
   <?php echo $__env->make('Layout.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldContent('customjs'); ?> 
</body>
</html><?php /**PATH C:\xampp\htdocs\class\tm\resources\views/Layout/baseview.blade.php ENDPATH**/ ?>